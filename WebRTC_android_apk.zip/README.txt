Android App Installation Guide


-------Step 1: Enable Unknown Sources
Go to Settings → Security or Privacy

Find "Unknown Sources" or "Install unknown apps"

Enable for your browser (Chrome/Firefox) or file manager


-------Step 2: Download the APK
Tap the "Android WebRTC.apk" link on the web page

Download the file to your device

Open your Downloads folder or notification


-------Step 3: Install the App
Tap the downloaded APK file

Tap "Install" when prompted

Wait for installation to complete

Tap "Open" or find "WebRTC Listener" in your apps

Required Permissions
The app will request these permissions:

First Launch:
Notifications - For incoming call alerts

Battery Optimization - To run in background

Background Activity - To receive calls when app closed

Important: Allow all permissions for full functionality.


Troubleshooting-----------------------


"Install blocked"
Enable "Unknown sources" in Settings

Grant "Install unknown apps" permission to your browser

App won't open
Clear app cache: Settings → Apps → WebRTC Listener → Storage → Clear Cache

Reinstall the APK

No incoming calls
Check notification permissions are enabled

Disable battery optimization for the app

Ensure background permission is granted